"""OpsDB Windows Server plugin — collectors v2.0.0

Requires: pywinrm — add to backend/requirements.txt to enable.

Standard interface consumed by plugin_loader:
    test_connection(params: dict) -> dict
    run_collector(collector_key: str, params: dict, query_params: dict) -> dict
"""

import json
import socket
import time


# ---------------------------------------------------------------------------
# Connection test — TCP reachability on WinRM port
# ---------------------------------------------------------------------------

def test_connection(params: dict) -> dict:
    host = str(params.get("host", ""))
    if not host:
        return {"success": False, "message": "Host is required."}
    port = int(params.get("winrm_port", 5985))
    try:
        t0 = time.perf_counter()
        s = socket.create_connection((host, port), timeout=5)
        s.close()
        latency = int((time.perf_counter() - t0) * 1000)
        return {
            "success": True,
            "message": f"WinRM port {port} reachable on {host}",
            "latency_ms": latency,
        }
    except Exception as exc:
        return {"success": False, "message": str(exc)}


# ---------------------------------------------------------------------------
# Collector runner — WinRM PowerShell execution
# ---------------------------------------------------------------------------

def run_collector(collector_key: str, params: dict, query_params: dict) -> dict:
    try:
        import winrm  # type: ignore[import]
    except ImportError:
        raise RuntimeError(
            "Windows collector requires 'pywinrm'. "
            "Add 'pywinrm' to backend/requirements.txt and rebuild the backend container."
        )

    command = query_params.get("command")
    if not command:
        raise ValueError(f"No command configured for collector '{collector_key}'.")

    host = str(params.get("host", ""))
    if not host:
        raise ValueError("No host configured for Windows target.")

    port = int(params.get("winrm_port", 5985))
    username = str(params.get("username", "Administrator"))
    password = params.get("password") or ""
    use_ssl = str(params.get("use_ssl", "no")).lower() == "yes"
    domain = str(params.get("domain", "")).strip()

    # Domain-prefix the username when a domain is specified
    auth_user = f"{domain}\\{username}" if domain else username
    protocol = "https" if use_ssl else "http"

    session = winrm.Session(
        f"{protocol}://{host}:{port}/wsman",
        auth=(auth_user, password),
        transport="ntlm",
        server_cert_validation="ignore",
    )

    result = session.run_ps(command)
    if result.status_code != 0:
        err = result.std_err.decode("utf-8", errors="replace").strip()
        raise ValueError(
            f"WinRM PowerShell command failed (exit {result.status_code}): {err[:400]}"
        )

    output = result.std_out.decode("utf-8", errors="replace").strip()
    if not output:
        raise ValueError("WinRM command produced no output.")

    try:
        data = json.loads(output)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"WinRM output is not valid JSON: {exc}. "
            f"Output snippet: {output[:200]}"
        )

    return _parse_result(data)


# ---------------------------------------------------------------------------
# Result normalisation
# ---------------------------------------------------------------------------

def _parse_result(data) -> dict:
    """Parse PowerShell JSON output into the standard OpsDB collector result format.

    Handles:
      - dict  → flat key/value pairs (e.g. {cpu_usage_percent: 45.2})
      - list  → tabular rows (e.g. [{drive: 'C', used_pct: 70}, ...])

    Returns:
      {metric_name: float}  — numeric values from the first row/object → MetricSamples
      "_rows": [...]        — all rows as string-valued dicts for UI display
      "_columns": [...]     — ordered column names
    """
    if isinstance(data, list):
        if not data:
            return {"_rows": [], "_columns": []}
        rows = data
        columns = list(rows[0].keys()) if rows else []
        result: dict = {}
        # Extract numeric metrics from the first row only
        for k, v in rows[0].items():
            coerced = _coerce_numeric(v)
            if coerced is not None:
                result[k] = coerced
        result["_rows"] = [_stringify_row(r) for r in rows]
        result["_columns"] = columns
        return result

    if isinstance(data, dict):
        result = {}
        for k, v in data.items():
            coerced = _coerce_numeric(v)
            if coerced is not None:
                result[k] = coerced
        # Expose as a single display row so collectors show up in the results grid
        result["_rows"] = [_stringify_row(data)]
        result["_columns"] = list(data.keys())
        return result

    raise ValueError(
        f"Unexpected JSON root type from PowerShell: {type(data).__name__}. "
        "Commands must return a JSON object or JSON array."
    )


def _stringify_row(row: dict) -> dict:
    """Convert all values in a row dict to display strings."""
    return {k: ("" if v is None else str(v)) for k, v in row.items()}


def _coerce_numeric(value) -> "float | None":
    """Convert a JSON-decoded value to float for MetricSample storage.

    Handles the types PowerShell commonly returns via ConvertTo-Json:
      bool   → 0.0 / 1.0
      int    → float
      float  → float
      str    → float if parseable, otherwise None (display-only)
      None   → None (skipped)
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except (TypeError, ValueError):
            return None
    return None
